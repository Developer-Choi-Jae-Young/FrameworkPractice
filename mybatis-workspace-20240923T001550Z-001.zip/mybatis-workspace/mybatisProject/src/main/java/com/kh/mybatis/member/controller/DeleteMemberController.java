package com.kh.mybatis.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.mybatis.member.service.MemberServiceImpl;

@WebServlet("/delete.me")
public class DeleteMemberController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("userId");
		String pwd = req.getParameter("userPwd");
		
		int result = new MemberServiceImpl().deleteMember(id, pwd);
		
		if (result > 0) {
			req.getSession().invalidate();
			req.getSession().setAttribute("alertMsg", "회원 탈퇴에 성공했습니다. 그동안 이용해주셔 감사합니다.");
			
			resp.sendRedirect(req.getContextPath());
		} else {
			req.setAttribute("errorMsg", "회원 탈퇴에 실패했습니다.");
			req.getRequestDispatcher("WEB-INF/views/common/errorPage.jsp")
			       .forward(req, resp);
		}
	}

}
