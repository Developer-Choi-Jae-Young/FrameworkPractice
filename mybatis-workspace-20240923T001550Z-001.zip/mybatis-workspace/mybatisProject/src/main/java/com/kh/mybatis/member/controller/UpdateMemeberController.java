package com.kh.mybatis.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.mybatis.member.model.vo.Member;
import com.kh.mybatis.member.service.MemberServiceImpl;

@WebServlet("/update.me")
public class UpdateMemeberController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("userId");
		String name = req.getParameter("userName");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		String birthday = req.getParameter("birthday");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		
		Member m = new Member(id, name, email, birthday, gender, phone, address);
		
		Member updateMem = new MemberServiceImpl().updateMember(m);
		
		if (updateMem == null) {
			req.setAttribute("errorMsg", "정보 수정에 실패하였습니다.");
			req.getRequestDispatcher("WEB-INF/views/common/errorPage.jsp").forward(req, resp);
		} else {
			HttpSession session = req.getSession();
			
			session.setAttribute("alertMsg", "정보 수정에 성공하였습니다.");
			session.setAttribute("loginUser", updateMem);
			
			resp.sendRedirect(req.getContextPath() + "/myPage.me");
		}
	}

	
}
