package com.kh.mybatis.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.mybatis.member.model.vo.Member;
import com.kh.mybatis.member.service.MemberServiceImpl;

@WebServlet("/updatePwd.me")
public class UpdatePasswordController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userId = req.getParameter("userId");
		String userPwd = req.getParameter("userPwd");
		String newPassword = req.getParameter("newPassword");
		
		Member updateMem = new MemberServiceImpl().updatePassword(userId, userPwd, newPassword);
		
		if (updateMem == null) {
			req.setAttribute("errorMsg", "비밀번호 변경에 실패했습니다.");
			req.getRequestDispatcher("WEB-INF/views/common/errorPage.jsp")
			       .forward(req, resp);
		} else {
			HttpSession session = req.getSession();
			session.setAttribute("alertMsg", "비밀번호 변경에 성공했습니다.");			
			session.setAttribute("loginUser", updateMem);
			
			resp.sendRedirect( req.getContextPath() + "/myPage.me" );  			
		}
	}
	
}
